let handler = m => m

handler.before = function (m) {
  let user = global.db.data.users[m.sender]
        let role = (user.level <= 10) ? 'Bronze'
          : ((user.level >= 10) && (user.level <= 20)) ? '*SILVER*'
          : ((user.level >= 20) && (user.level <= 30)) ? '*GOLD*'
          : ((user.level >= 30) && (user.level <= 40)) ? '*PLATINUM*'
          : ((user.level >= 40) && (user.level <= 50)) ? '*EMERALD'
          : ((user.level >= 50) && (user.level <= 60)) ? '*DIAMOND*'
		  : ((user.level >= 60) && (user.level <= 70)) ? '*ACE*'
          : ((user.level >= 70) && (user.level <= 80)) ? '*MASTER*'
          : ((user.level >= 80) && (user.level <= 90)) ? '*GRANDMASTER*'
		  : ((user.level >= 90) && (user.level <= 100)) ? '*CHALLENGER*'
          : '*CONQUEROR*'
  user.role = role
  return true
}

module.exports = handler
