let fetch = require("node-fetch")
const { sticker } = require('../lib/sticker')
const { MessageType } = require('@adiwajshing/baileys')

let handler = async (m, { conn}) => {
  try {
  let res = await fetch('https://api.waifu.pics/sfw/cuddle')
  let json = await res.json()
  let { 
url
} = json
let stiker = await sticker(null, url, 'Cuddle', 'Nishimiya')
  conn.sendMessage(m.chat, stiker, MessageType.sticker, {
    quoted: m
  })
 } catch (e) {
  }
}
handler.help = ['cuddle']
handler.tags = ['expression']
handler.command = /^cuddle/i

module.exports = handler