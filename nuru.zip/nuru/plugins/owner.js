let PhoneNumber = require('awesome-phonenumber')
let handler  = async (m, { conn, usedPrefix }) => {
  conn.reply(m.chat, `
━━❰ *･Bot🤖Mods･* ❱━━

*Tor II*
https://wa.me/+918709022955

━━❰ *NISHIMIYA* ❱━━

`.trim(), m)
}
handler.help = ['owner']
handler.tags = ['main']
handler.command = /^(owner)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler